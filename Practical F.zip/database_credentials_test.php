<?php
require('database_credentials');
$mysqli = new mysqli(servername,username,password,database);
  
// test connection
if ($mysqli -> connect_errno) {// check if there is an error
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error; // $mysqli -> connect_error describes the error
}
else {
  echo "Successfully connected";// return this message if it's successfull
}


