<h1>
    <?php
        $result2=$_POST['searchbox2'];
        echo $result2; 
    ?>
</h1>