<?php
function total(int $x, int $y){
    $z=$x+$y;
    return $z ;
}

?>