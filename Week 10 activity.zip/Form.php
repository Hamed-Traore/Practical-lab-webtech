<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body><h1>Google</h1>
<br>
<form action="" method="get">
    <div>
        <input type="text" name="searchbox1"placeholder="type here" >
    </div>
    <div>
        <button type="submit" name="sub1">submit</button>
    </div>
</form>
<br>
<?php
    if(isset( $_GET["sub1"])){
        echo "this is the result of search box 1 " , $_GET['searchbox1'];
        
    }
    
?>
<br>

<form action="results_page.php" method="post">
    <div>
        <input type="text" name="searchbox2" >
    </div>
    <div>
        <button type="submit" name="sub2">submit</button>
    </div>
</form>
</body>
</html>