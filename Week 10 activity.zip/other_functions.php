<?php
    function multiplyer($x){
        return $x * 100;
    }
    
?>